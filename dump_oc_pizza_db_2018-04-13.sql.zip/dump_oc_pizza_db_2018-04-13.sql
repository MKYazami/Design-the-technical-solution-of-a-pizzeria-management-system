# ************************************************************
# Sequel Pro SQL dump
# Version 4541
#
# http://www.sequelpro.com/
# https://github.com/sequelpro/sequelpro
#
# Host: 127.0.0.1 (MySQL 5.7.21)
# Database: oc_pizza_db
# Generation Time: 2018-04-13 21:45:22 +0000
# ************************************************************


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;


# Dump of table adresse
# ------------------------------------------------------------

DROP TABLE IF EXISTS `adresse`;

CREATE TABLE `adresse` (
  `id_adresse` int(11) NOT NULL AUTO_INCREMENT,
  `adresse` varchar(150) NOT NULL,
  `code_postal` char(5) NOT NULL,
  `ville` varchar(50) NOT NULL,
  PRIMARY KEY (`id_adresse`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `adresse` WRITE;
/*!40000 ALTER TABLE `adresse` DISABLE KEYS */;

INSERT INTO `adresse` (`id_adresse`, `adresse`, `code_postal`, `ville`)
VALUES
	(1,'3, rue Drouot','75009','Paris'),
	(2,'14, rue Rossini','75009','Paris'),
	(3,'33, rue Caplat','75018','Paris'),
	(4,'21, Avenue Claude Vellefaux','75010','Paris'),
	(5,'42, rue Albert Thomas','75010','Paris'),
	(6,'100, rue de Cléry','75002','Paris');

/*!40000 ALTER TABLE `adresse` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table adresse_client
# ------------------------------------------------------------

DROP TABLE IF EXISTS `adresse_client`;

CREATE TABLE `adresse_client` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `client_id` int(11) NOT NULL,
  `adresse_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_adresses_clients_client1_idx` (`client_id`),
  KEY `fk_adresses_clients_adresse_client1_idx` (`adresse_id`),
  CONSTRAINT `fk_adresses_clients_adresse_client1` FOREIGN KEY (`adresse_id`) REFERENCES `adresse` (`id_adresse`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_adresses_clients_client1` FOREIGN KEY (`client_id`) REFERENCES `client` (`id_client`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `adresse_client` WRITE;
/*!40000 ALTER TABLE `adresse_client` DISABLE KEYS */;

INSERT INTO `adresse_client` (`id`, `client_id`, `adresse_id`)
VALUES
	(1,1,1),
	(2,2,2),
	(3,2,3),
	(4,3,4),
	(5,4,5),
	(6,5,6);

/*!40000 ALTER TABLE `adresse_client` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table adresse_pizzeria
# ------------------------------------------------------------

DROP TABLE IF EXISTS `adresse_pizzeria`;

CREATE TABLE `adresse_pizzeria` (
  `id_adresse_pizzeria` int(11) NOT NULL AUTO_INCREMENT,
  `adresse` varchar(150) NOT NULL,
  `code_postal` char(5) NOT NULL,
  `ville` varchar(50) NOT NULL,
  PRIMARY KEY (`id_adresse_pizzeria`),
  UNIQUE KEY `adresse_code_postal_unique` (`code_postal`,`adresse`),
  KEY `ville_pizzeria_idx` (`ville`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `adresse_pizzeria` WRITE;
/*!40000 ALTER TABLE `adresse_pizzeria` DISABLE KEYS */;

INSERT INTO `adresse_pizzeria` (`id_adresse_pizzeria`, `adresse`, `code_postal`, `ville`)
VALUES
	(1,'24, rue de l\'Échiquier','75010','Paris'),
	(2,'40, rue d\'Anjou','75008','Paris'),
	(3,'37, rue de Clichy','75009','Paris'),
	(4,'7, rue des Bernardins','75005','Paris'),
	(5,'17, rue de Nevers','75006','Paris');

/*!40000 ALTER TABLE `adresse_pizzeria` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table client
# ------------------------------------------------------------

DROP TABLE IF EXISTS `client`;

CREATE TABLE `client` (
  `id_client` int(11) NOT NULL AUTO_INCREMENT,
  `nom` varchar(50) DEFAULT NULL,
  `prenom` varchar(50) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `mot_de_passe` varchar(255) DEFAULT NULL,
  `phone` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id_client`),
  UNIQUE KEY `email_UNIQUE` (`email`),
  KEY `nom_client_idx` (`nom`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `client` WRITE;
/*!40000 ALTER TABLE `client` DISABLE KEYS */;

INSERT INTO `client` (`id_client`, `nom`, `prenom`, `email`, `mot_de_passe`, `phone`)
VALUES
	(1,'Chevalier','Todd','em@massarutrum.com','5f4dcc3b5aa765d61d8327deb882cf99','06 36 68 66 21'),
	(2,'Ferris','Etienne','orci.tincidunt@orci.edu','68fa0a7db5c409738e098d15b5d1787e1b480d92','06 16 00 89 76'),
	(3,'Isaiah','Gauthier','Vivamus.euismod.urna@Nunc.org','f4c16fcffe10dc7743ab27040ac0a805b3d54f9a','06 78 32 65 87'),
	(4,'Eric','Denis','Etiam.laoreet@montes.org','6b49f5ef5fbb16b95caea530a65128a860fe8dc1','06 34 67 19 98'),
	(5,'Kermit','Barbier','quis.accumsan@vitaerisusDuis.net','b7e8b8e70d4d778b61de0c532d21a4867b280020','06 48 66 85 89');

/*!40000 ALTER TABLE `client` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table commande
# ------------------------------------------------------------

DROP TABLE IF EXISTS `commande`;

CREATE TABLE `commande` (
  `numero_commande` int(11) NOT NULL AUTO_INCREMENT,
  `heure_date` datetime NOT NULL,
  `coordonnees_pizzeria_id` int(11) NOT NULL,
  `client_id` int(11) DEFAULT NULL,
  `quantitee_pizza` tinyint(1) NOT NULL,
  PRIMARY KEY (`numero_commande`),
  UNIQUE KEY `numero_commande_UNIQUE` (`numero_commande`),
  KEY `fk_commande_client_idx` (`client_id`),
  KEY `fk_commande_pizzeria_idx` (`coordonnees_pizzeria_id`),
  CONSTRAINT `fk_commande_client1` FOREIGN KEY (`client_id`) REFERENCES `client` (`id_client`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_commande_pizzeria1` FOREIGN KEY (`coordonnees_pizzeria_id`) REFERENCES `pizzeria` (`id_pizzeria`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `commande` WRITE;
/*!40000 ALTER TABLE `commande` DISABLE KEYS */;

INSERT INTO `commande` (`numero_commande`, `heure_date`, `coordonnees_pizzeria_id`, `client_id`, `quantitee_pizza`)
VALUES
	(12778,'2018-01-19 18:14:07',1,3,2),
	(12779,'2018-01-20 11:42:23',3,5,1),
	(12780,'2018-01-21 13:22:43',4,1,3),
	(12781,'2018-01-21 19:06:57',4,2,1);

/*!40000 ALTER TABLE `commande` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table commande_enregistree
# ------------------------------------------------------------

DROP TABLE IF EXISTS `commande_enregistree`;

CREATE TABLE `commande_enregistree` (
  `id_commande_enregistree` int(11) NOT NULL AUTO_INCREMENT,
  `travailleur_pizzeria_id` int(11) NOT NULL,
  `numero_commande` int(11) NOT NULL,
  PRIMARY KEY (`id_commande_enregistree`),
  KEY `fk_commande_enregistree_commande1_idx` (`numero_commande`),
  KEY `fk_commande_enregistree_travailleur_pizzeria1_idx` (`travailleur_pizzeria_id`),
  CONSTRAINT `fk_commande_enregistree_commande1` FOREIGN KEY (`numero_commande`) REFERENCES `commande` (`numero_commande`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_commande_enregistree_travailleur_pizzeria1` FOREIGN KEY (`travailleur_pizzeria_id`) REFERENCES `travailleur_pizzeria` (`id_travailleurs`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `commande_enregistree` WRITE;
/*!40000 ALTER TABLE `commande_enregistree` DISABLE KEYS */;

INSERT INTO `commande_enregistree` (`id_commande_enregistree`, `travailleur_pizzeria_id`, `numero_commande`)
VALUES
	(1,3,12781);

/*!40000 ALTER TABLE `commande_enregistree` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table pizza
# ------------------------------------------------------------

DROP TABLE IF EXISTS `pizza`;

CREATE TABLE `pizza` (
  `id_pizza` int(11) NOT NULL AUTO_INCREMENT,
  `nom` varchar(70) NOT NULL,
  `description` text,
  `url_image` varchar(200) DEFAULT NULL,
  `prix` decimal(5,2) NOT NULL,
  PRIMARY KEY (`id_pizza`),
  UNIQUE KEY `nom_UNIQUE` (`nom`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `pizza` WRITE;
/*!40000 ALTER TABLE `pizza` DISABLE KEYS */;

INSERT INTO `pizza` (`id_pizza`, `nom`, `description`, `url_image`, `prix`)
VALUES
	(1,'Pizza maison quatre saisons','Une pizza maison du début à la fin, avec une pâte garnie d\'une sauce tomate et de légumes cuisinés','/web/images/pizza_quatre_saisons',6.00),
	(2,'Pizza aux légumes confits et parmesan','Une pizza estivale et végétarienne aux saveurs d\'antipasti avec des tomates, des artichauts et des poivrons confits, le tout agrémenté de roquette et de copeaux de parmesan','/web/images/legumes_confits_parmesan',5.00),
	(3,'Recette de Pizza façon bolognaise','Une pizza fine garnie d\'un mélange à base de pulpe de tomates et de boeuf haché préparé avec des aromates','/web/images/pizza_facon_bolognaise',8.50),
	(4,'ecette de Pizza Marinera','Une pizza de la mer à base de tomates, de gambas, de moules et de mozzarella','/web/images/pizza_marinera',9.90);

/*!40000 ALTER TABLE `pizza` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table pizza_commandee
# ------------------------------------------------------------

DROP TABLE IF EXISTS `pizza_commandee`;

CREATE TABLE `pizza_commandee` (
  `id_pizza_commandee` int(11) NOT NULL AUTO_INCREMENT,
  `numero_commande` int(11) NOT NULL,
  `pizza_id` int(11) NOT NULL,
  PRIMARY KEY (`id_pizza_commandee`),
  KEY `fk_pizza_commandee_commande1_idx` (`numero_commande`),
  KEY `fk_pizza_commandee_pizza1_idx` (`pizza_id`),
  CONSTRAINT `fk_pizza_commandee_commande1` FOREIGN KEY (`numero_commande`) REFERENCES `commande` (`numero_commande`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_pizza_commandee_pizza1` FOREIGN KEY (`pizza_id`) REFERENCES `pizza` (`id_pizza`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `pizza_commandee` WRITE;
/*!40000 ALTER TABLE `pizza_commandee` DISABLE KEYS */;

INSERT INTO `pizza_commandee` (`id_pizza_commandee`, `numero_commande`, `pizza_id`)
VALUES
	(1,12778,1),
	(2,12778,1),
	(3,12779,3),
	(4,12780,4),
	(5,12780,4),
	(9,12780,1),
	(10,12781,2);

/*!40000 ALTER TABLE `pizza_commandee` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table pizzeria
# ------------------------------------------------------------

DROP TABLE IF EXISTS `pizzeria`;

CREATE TABLE `pizzeria` (
  `id_pizzeria` int(11) NOT NULL AUTO_INCREMENT,
  `nom` varchar(70) DEFAULT NULL,
  `adresse_pizzeria_id` int(11) NOT NULL,
  `phone` varchar(40) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id_pizzeria`),
  UNIQUE KEY `nom_UNIQUE` (`nom`),
  UNIQUE KEY `email_UNIQUE` (`email`),
  UNIQUE KEY `phone_UNIQUE` (`phone`),
  KEY `fk_pizzeria_adresse_pizzeria1_idx` (`adresse_pizzeria_id`),
  CONSTRAINT `fk_pizzeria_adresse_pizzeria1` FOREIGN KEY (`adresse_pizzeria_id`) REFERENCES `adresse_pizzeria` (`id_adresse_pizzeria`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `pizzeria` WRITE;
/*!40000 ALTER TABLE `pizzeria` DISABLE KEYS */;

INSERT INTO `pizzeria` (`id_pizzeria`, `nom`, `adresse_pizzeria_id`, `phone`, `email`)
VALUES
	(1,'Du Bolle',1,'01 56 61 55 51','dubolle@oc-pizza.com'),
	(2,'Du Cartier',3,'01 96 95 76 67','ducartier@oc-pizza.com'),
	(3,'Au Chaud',2,'01 82 04 36 37','auchaud@oc-pizza.com'),
	(4,'A l\'Air',4,'01 33 97 35 10','alair@oc-pizza.com'),
	(7,'Au Soleil',5,'01 61 87 22 91','ausoleil@oc-pizza.com');

/*!40000 ALTER TABLE `pizzeria` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table produit
# ------------------------------------------------------------

DROP TABLE IF EXISTS `produit`;

CREATE TABLE `produit` (
  `id_produit` int(11) NOT NULL AUTO_INCREMENT,
  `nom_produit` varchar(100) NOT NULL,
  PRIMARY KEY (`id_produit`),
  UNIQUE KEY `nom_produit_UNIQUE` (`nom_produit`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `produit` WRITE;
/*!40000 ALTER TABLE `produit` DISABLE KEYS */;

INSERT INTO `produit` (`id_produit`, `nom_produit`)
VALUES
	(13,'Asperge verte'),
	(7,'Champigon de Paris'),
	(6,'Concentré de tomate'),
	(14,'Eau'),
	(1,'Farine de blé'),
	(11,'Fruit de mére'),
	(4,'Huile d\'olive'),
	(2,'Levure de boulanger'),
	(15,'Mozzarella'),
	(5,'Oignon'),
	(16,'Parmesan'),
	(12,'Poivre'),
	(9,'Poivron jaune'),
	(8,'Poivron rouge'),
	(3,'Sel'),
	(10,'Viande hachée');

/*!40000 ALTER TABLE `produit` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table recette_pizza
# ------------------------------------------------------------

DROP TABLE IF EXISTS `recette_pizza`;

CREATE TABLE `recette_pizza` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `pizza_id` int(11) NOT NULL,
  `produit_id` int(11) NOT NULL,
  `quantite_produit` decimal(5,2) NOT NULL,
  `unite_de_mesure` varchar(20) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_recette_pizza_pizza_idx` (`pizza_id`),
  KEY `fk_recette_pizza_produit_idx` (`produit_id`),
  CONSTRAINT `fk_recette_pizza_pizza1` FOREIGN KEY (`pizza_id`) REFERENCES `pizza` (`id_pizza`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_recette_pizza_produit1` FOREIGN KEY (`produit_id`) REFERENCES `produit` (`id_produit`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `recette_pizza` WRITE;
/*!40000 ALTER TABLE `recette_pizza` DISABLE KEYS */;

INSERT INTO `recette_pizza` (`id`, `pizza_id`, `produit_id`, `quantite_produit`, `unite_de_mesure`)
VALUES
	(1,1,1,69.00,'g'),
	(2,1,14,25.00,'cl'),
	(3,1,2,14.00,'g'),
	(4,1,3,2.20,'g'),
	(5,1,5,1.00,'Pièce'),
	(6,1,8,1.00,'Pièce'),
	(7,1,9,1.00,'Pièce'),
	(8,1,15,60.00,'g'),
	(9,2,1,69.00,'g'),
	(10,2,14,25.00,'cl'),
	(11,2,2,14.00,'g'),
	(12,2,3,2.20,'g'),
	(13,2,5,1.00,'Pièce'),
	(15,2,12,5.00,'g'),
	(16,2,13,4.00,'Pièces'),
	(17,3,1,69.00,'g'),
	(18,3,2,14.00,'g'),
	(19,3,14,25.00,'cl'),
	(20,3,5,1.00,'Pièce'),
	(21,3,15,60.00,'g'),
	(24,1,6,100.00,'g'),
	(25,2,6,100.00,'g'),
	(26,3,6,150.00,'g'),
	(27,3,6,100.00,'g'),
	(28,2,16,68.00,'g'),
	(30,3,1,69.00,'g'),
	(31,3,14,25.00,'cl'),
	(32,3,2,14.00,'g'),
	(33,3,3,2.20,'g'),
	(34,3,5,1.00,'Pièce'),
	(35,3,15,60.00,'g'),
	(36,3,11,120.00,'g');

/*!40000 ALTER TABLE `recette_pizza` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table stock_pizzeria
# ------------------------------------------------------------

DROP TABLE IF EXISTS `stock_pizzeria`;

CREATE TABLE `stock_pizzeria` (
  `id_stock` int(11) NOT NULL AUTO_INCREMENT,
  `pizzeria_id` int(11) NOT NULL,
  `produit_id` int(11) NOT NULL,
  `quantite` decimal(7,2) NOT NULL,
  `unite_de_mesure` varchar(20) NOT NULL,
  PRIMARY KEY (`id_stock`),
  KEY `fk_stock_pizzeria_pizzeria1_idx` (`pizzeria_id`),
  KEY `fk_stock_pizzeria_produit1_idx` (`produit_id`),
  CONSTRAINT `fk_stock_pizzeria_pizzeria1` FOREIGN KEY (`pizzeria_id`) REFERENCES `pizzeria` (`id_pizzeria`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_stock_pizzeria_produit1` FOREIGN KEY (`produit_id`) REFERENCES `produit` (`id_produit`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `stock_pizzeria` WRITE;
/*!40000 ALTER TABLE `stock_pizzeria` DISABLE KEYS */;

INSERT INTO `stock_pizzeria` (`id_stock`, `pizzeria_id`, `produit_id`, `quantite`, `unite_de_mesure`)
VALUES
	(2,1,1,500.00,'kg'),
	(3,1,2,150.00,'kg'),
	(4,1,3,20.00,'kg'),
	(5,1,4,60.00,'Ltr'),
	(6,1,5,110.00,'Pièces'),
	(7,1,6,200.00,'Ltr'),
	(8,1,7,100.00,'Pièces'),
	(9,1,8,60.00,'Pièces'),
	(10,1,9,60.00,'Pièces'),
	(11,1,10,25.00,'kg'),
	(12,1,11,12.00,'kg'),
	(13,1,12,18.00,'kg'),
	(15,1,13,60.00,'Pièces'),
	(16,1,14,1000.00,'Ltr'),
	(17,1,15,160.00,'kg'),
	(18,1,16,120.00,'kg'),
	(53,2,1,500.00,'kg'),
	(54,2,2,150.00,'kg'),
	(55,2,3,20.00,'kg'),
	(56,2,4,60.00,'Ltr'),
	(57,2,5,110.00,'Pièces'),
	(58,2,6,200.00,'Ltr'),
	(59,2,7,100.00,'Pièces'),
	(60,2,8,60.00,'Pièces'),
	(61,2,9,60.00,'Pièces'),
	(62,2,10,25.00,'kg'),
	(63,2,11,12.00,'kg'),
	(64,2,12,18.00,'kg'),
	(65,2,13,60.00,'Pièces'),
	(66,2,14,1000.00,'Ltr'),
	(67,2,15,160.00,'kg'),
	(68,2,16,120.00,'kg'),
	(69,3,1,500.00,'kg'),
	(70,3,2,150.00,'kg'),
	(71,3,3,20.00,'kg'),
	(72,3,4,60.00,'Ltr'),
	(73,3,5,110.00,'Pièces'),
	(74,3,6,200.00,'Ltr'),
	(75,3,7,100.00,'Pièces'),
	(76,3,8,60.00,'Pièces'),
	(77,3,9,60.00,'Pièces'),
	(78,3,10,25.00,'kg'),
	(79,3,11,12.00,'kg'),
	(80,3,12,18.00,'kg'),
	(81,3,13,60.00,'Pièces'),
	(82,3,14,1000.00,'Ltr'),
	(83,3,15,160.00,'kg'),
	(84,3,16,120.00,'kg'),
	(85,4,1,500.00,'kg'),
	(86,4,2,150.00,'kg'),
	(87,4,3,20.00,'kg'),
	(88,4,4,60.00,'Ltr'),
	(89,4,5,110.00,'Pièces'),
	(90,4,6,200.00,'Ltr'),
	(91,4,7,100.00,'Pièces'),
	(92,4,8,60.00,'Pièces'),
	(93,4,9,60.00,'Pièces'),
	(94,4,10,25.00,'kg'),
	(95,4,11,12.00,'kg'),
	(96,4,12,18.00,'kg'),
	(97,4,13,60.00,'Pièces'),
	(98,4,14,1000.00,'Ltr'),
	(99,4,15,160.00,'kg'),
	(100,4,16,120.00,'kg');

/*!40000 ALTER TABLE `stock_pizzeria` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table travailleur_pizzeria
# ------------------------------------------------------------

DROP TABLE IF EXISTS `travailleur_pizzeria`;

CREATE TABLE `travailleur_pizzeria` (
  `id_travailleurs` int(11) NOT NULL AUTO_INCREMENT,
  `nom` varchar(50) NOT NULL,
  `prenom` varchar(50) NOT NULL,
  `fonction` varchar(50) NOT NULL,
  `pizzeria_id` int(11) NOT NULL,
  `email` varchar(100) DEFAULT NULL,
  `mot_de_passe` varchar(255) NOT NULL,
  PRIMARY KEY (`id_travailleurs`),
  UNIQUE KEY `id_travailleurs_UNIQUE` (`id_travailleurs`),
  UNIQUE KEY `nom_prenom_unique` (`nom`,`prenom`),
  UNIQUE KEY `email_UNIQUE` (`email`),
  KEY `nom_travailleur` (`nom`),
  KEY `fk_travailleur_pizzeria_pizzeria1_idx` (`pizzeria_id`),
  CONSTRAINT `fk_travailleur_pizzeria_pizzeria1` FOREIGN KEY (`pizzeria_id`) REFERENCES `pizzeria` (`id_pizzeria`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `travailleur_pizzeria` WRITE;
/*!40000 ALTER TABLE `travailleur_pizzeria` DISABLE KEYS */;

INSERT INTO `travailleur_pizzeria` (`id_travailleurs`, `nom`, `prenom`, `fonction`, `pizzeria_id`, `email`, `mot_de_passe`)
VALUES
	(2,'Hervé','Xavier','Directeur Général',1,'herve.xavier@oc-pizza.com','356a192b7913b04c54574d18c28d46e6395428ab'),
	(3,'Leonard','Collin','Employé Pizzeria',1,'leonard.collin@oc-pizza.com','da4b9237bacccdf19c0760cab7aec4a8359010b0'),
	(5,'Josiah','Daniel','Pizzaiolo',1,'josiah.daniel@oc-pizza.com','77de68daecd823babbb58edb1c8e14d7106e83bb'),
	(6,'Moses','Weber','Livreur',1,'moses.weber@oc-pizza.com','1b6453892473a467d07372d45eb05abc2031647a'),
	(7,'Fitzgerald','Chevallier','Employé Pizzeria',2,'fitzgerald.chevallier@oc-pizza.com','ac3478d69a3c81fa62e60f5c3696165a4e5e6ac4'),
	(8,'Zane','Sanchez','Pizzaiolo',2,'zane.sanchez@oc-pizza.com','c1dfd96eea8cc2b62785275bca38ac261256e278'),
	(9,'Kadeem','Warin','Livreur',2,'kadeem.warin@oc-pizza.com','902ba3cda1883801594b6e1b452790cc53948fda'),
	(10,'Stephen','Etienne','Employé Pizzeria',3,'stephen.etienne@oc-pizza.com','fe5dbbcea5ce7e2988b8c69bcfdfde8904aabc1f'),
	(11,'Rafael','Perrot','Pizzaiolo',3,'rafael.perrot@oc-pizza.com','0ade7c2cf97f75d009975f4d720d1fa6c19f4897'),
	(12,'Magee','Michel','Livreur',3,'magee.michel@oc-pizza.com','b1d5781111d84f7b3fe45a0852e59758cd7a87e5'),
	(13,'Vincent','Daniel','Employé Pizzeria',4,'vincent.daniel@oc-pizza.com','7b52009b64fd0a2a49e6d8a939753077792b0554'),
	(14,'Alden','Rolland','Pizzaiolo',4,'alden.rolland@oc-pizza.com','bd307a3ec329e10a2cff8fb87480823da114f8f4'),
	(15,'Jonah','Lemoine','Livreur',4,'jonah.lemoine@oc-pizza.com','fa35e192121eabf3dabf9f5ea6abdbcbc107ac3b'),
	(18,'Lucius','Guyot','Employé Pizzeria',7,'lucius.guyot@oc-pizza.com','1574bddb75c78a6fd2251d61e2993b5146201319'),
	(19,'Flynn','Bonnet','Pizzaiolo',7,'flynn.bonnet@oc-pizza.com','6216f8a75fd5bb3d5f22b6f9958cdede3fc086c2'),
	(20,'David','Girard','Livreur',7,'david.girard@oc-pizza.com','410cb324333e13a419c56493c00cc22aa98f2188');

/*!40000 ALTER TABLE `travailleur_pizzeria` ENABLE KEYS */;
UNLOCK TABLES;



/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
