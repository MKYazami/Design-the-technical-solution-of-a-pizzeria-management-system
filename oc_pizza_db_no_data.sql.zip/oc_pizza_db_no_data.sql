-- MySQL Workbench Forward Engineering

SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0;
SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;
SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='TRADITIONAL,ALLOW_INVALID_DATES';

-- -----------------------------------------------------
-- Schema oc_pizza_db
-- -----------------------------------------------------

-- -----------------------------------------------------
-- Schema oc_pizza_db
-- -----------------------------------------------------
CREATE SCHEMA IF NOT EXISTS `oc_pizza_db` DEFAULT CHARACTER SET utf8 ;
USE `oc_pizza_db` ;

-- -----------------------------------------------------
-- Table `oc_pizza_db`.`client`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `oc_pizza_db`.`client` (
  `id_client` INT NOT NULL AUTO_INCREMENT,
  `nom` VARCHAR(50) NULL,
  `prenom` VARCHAR(50) NULL,
  `email` VARCHAR(100) NULL,
  `mot_de_passe` VARCHAR(255) NULL,
  `phone` VARCHAR(30) NULL,
  PRIMARY KEY (`id_client`),
  UNIQUE INDEX `email_UNIQUE` (`email` ASC),
  INDEX `nom_client_idx` (`nom` ASC))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `oc_pizza_db`.`adresse`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `oc_pizza_db`.`adresse` (
  `id_adresse` INT NOT NULL AUTO_INCREMENT,
  `adresse` VARCHAR(150) NOT NULL,
  `code_postal` CHAR(5) NOT NULL,
  `ville` VARCHAR(50) NOT NULL,
  PRIMARY KEY (`id_adresse`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `oc_pizza_db`.`pizza`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `oc_pizza_db`.`pizza` (
  `id_pizza` INT NOT NULL AUTO_INCREMENT,
  `nom` VARCHAR(70) NOT NULL,
  `description` TEXT(10000) NULL,
  `url_image` VARCHAR(200) NULL,
  `prix` DECIMAL(5,2) NOT NULL,
  PRIMARY KEY (`id_pizza`),
  UNIQUE INDEX `nom_UNIQUE` (`nom` ASC))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `oc_pizza_db`.`adresse_pizzeria`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `oc_pizza_db`.`adresse_pizzeria` (
  `id_adresse_pizzeria` INT NOT NULL AUTO_INCREMENT,
  `adresse` VARCHAR(150) NOT NULL,
  `code_postal` CHAR(5) NOT NULL,
  `ville` VARCHAR(50) NOT NULL,
  PRIMARY KEY (`id_adresse_pizzeria`),
  INDEX `ville_pizzeria_idx` (`ville` ASC),
  UNIQUE INDEX `adresse_code_postal_unique` (`code_postal` ASC, `adresse` ASC))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `oc_pizza_db`.`pizzeria`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `oc_pizza_db`.`pizzeria` (
  `id_pizzeria` INT NOT NULL AUTO_INCREMENT,
  `nom` VARCHAR(70) NULL,
  `adresse_pizzeria_id` INT NOT NULL,
  `phone` VARCHAR(40) NULL,
  `email` VARCHAR(100) NULL,
  PRIMARY KEY (`id_pizzeria`),
  UNIQUE INDEX `nom_UNIQUE` (`nom` ASC),
  INDEX `fk_pizzeria_adresse_pizzeria1_idx` (`adresse_pizzeria_id` ASC),
  UNIQUE INDEX `email_UNIQUE` (`email` ASC),
  UNIQUE INDEX `phone_UNIQUE` (`phone` ASC),
  CONSTRAINT `fk_pizzeria_adresse_pizzeria1`
    FOREIGN KEY (`adresse_pizzeria_id`)
    REFERENCES `oc_pizza_db`.`adresse_pizzeria` (`id_adresse_pizzeria`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `oc_pizza_db`.`commande`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `oc_pizza_db`.`commande` (
  `numero_commande` INT NOT NULL AUTO_INCREMENT,
  `heure_date` DATETIME NOT NULL,
  `coordonnees_pizzeria_id` INT NOT NULL,
  `client_id` INT NULL,
  `quantitee_pizza` TINYINT(1) NOT NULL,
  PRIMARY KEY (`numero_commande`),
  UNIQUE INDEX `numero_commande_UNIQUE` (`numero_commande` ASC),
  INDEX `fk_commande_client_idx` (`client_id` ASC),
  INDEX `fk_commande_pizzeria_idx` (`coordonnees_pizzeria_id` ASC),
  CONSTRAINT `fk_commande_client1`
    FOREIGN KEY (`client_id`)
    REFERENCES `oc_pizza_db`.`client` (`id_client`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_commande_pizzeria1`
    FOREIGN KEY (`coordonnees_pizzeria_id`)
    REFERENCES `oc_pizza_db`.`pizzeria` (`id_pizzeria`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `oc_pizza_db`.`pizza_commandee`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `oc_pizza_db`.`pizza_commandee` (
  `id_pizza_commandee` INT NOT NULL AUTO_INCREMENT,
  `numero_commande` INT NOT NULL,
  `pizza_id` INT NOT NULL,
  PRIMARY KEY (`id_pizza_commandee`),
  INDEX `fk_pizza_commandee_commande1_idx` (`numero_commande` ASC),
  INDEX `fk_pizza_commandee_pizza1_idx` (`pizza_id` ASC),
  CONSTRAINT `fk_pizza_commandee_commande1`
    FOREIGN KEY (`numero_commande`)
    REFERENCES `oc_pizza_db`.`commande` (`numero_commande`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_pizza_commandee_pizza1`
    FOREIGN KEY (`pizza_id`)
    REFERENCES `oc_pizza_db`.`pizza` (`id_pizza`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `oc_pizza_db`.`produit`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `oc_pizza_db`.`produit` (
  `id_produit` INT NOT NULL AUTO_INCREMENT,
  `nom_produit` VARCHAR(100) NOT NULL,
  PRIMARY KEY (`id_produit`),
  UNIQUE INDEX `nom_produit_UNIQUE` (`nom_produit` ASC))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `oc_pizza_db`.`stock_pizzeria`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `oc_pizza_db`.`stock_pizzeria` (
  `id_stock` INT NOT NULL AUTO_INCREMENT,
  `pizzeria_id` INT NOT NULL,
  `produit_id` INT NOT NULL,
  `quantite` DECIMAL(7,2) NOT NULL,
  `unite_de_mesure` VARCHAR(20) NOT NULL,
  PRIMARY KEY (`id_stock`),
  INDEX `fk_stock_pizzeria_pizzeria1_idx` (`pizzeria_id` ASC),
  INDEX `fk_stock_pizzeria_produit1_idx` (`produit_id` ASC),
  CONSTRAINT `fk_stock_pizzeria_pizzeria1`
    FOREIGN KEY (`pizzeria_id`)
    REFERENCES `oc_pizza_db`.`pizzeria` (`id_pizzeria`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_stock_pizzeria_produit1`
    FOREIGN KEY (`produit_id`)
    REFERENCES `oc_pizza_db`.`produit` (`id_produit`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `oc_pizza_db`.`travailleur_pizzeria`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `oc_pizza_db`.`travailleur_pizzeria` (
  `id_travailleurs` INT NOT NULL AUTO_INCREMENT,
  `nom` VARCHAR(50) NOT NULL,
  `prenom` VARCHAR(50) NOT NULL,
  `fonction` VARCHAR(50) NOT NULL,
  `pizzeria_id` INT NOT NULL,
  `email` VARCHAR(100) NULL,
  `mot_de_passe` VARCHAR(255) NOT NULL,
  PRIMARY KEY (`id_travailleurs`),
  INDEX `nom_travailleur` (`nom` ASC),
  UNIQUE INDEX `email_UNIQUE` (`email` ASC),
  UNIQUE INDEX `id_travailleurs_UNIQUE` (`id_travailleurs` ASC),
  UNIQUE INDEX `nom_prenom_unique` (`nom` ASC, `prenom` ASC),
  INDEX `fk_travailleur_pizzeria_pizzeria1_idx` (`pizzeria_id` ASC),
  CONSTRAINT `fk_travailleur_pizzeria_pizzeria1`
    FOREIGN KEY (`pizzeria_id`)
    REFERENCES `oc_pizza_db`.`pizzeria` (`id_pizzeria`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `oc_pizza_db`.`recette_pizza`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `oc_pizza_db`.`recette_pizza` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `pizza_id` INT NOT NULL,
  `produit_id` INT NOT NULL,
  `quantite_produit` DECIMAL(5,2) NOT NULL,
  `unite_de_mesure` VARCHAR(20) NOT NULL,
  PRIMARY KEY (`id`),
  INDEX `fk_recette_pizza_pizza_idx` (`pizza_id` ASC),
  INDEX `fk_recette_pizza_produit_idx` (`produit_id` ASC),
  CONSTRAINT `fk_recette_pizza_pizza1`
    FOREIGN KEY (`pizza_id`)
    REFERENCES `oc_pizza_db`.`pizza` (`id_pizza`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_recette_pizza_produit1`
    FOREIGN KEY (`produit_id`)
    REFERENCES `oc_pizza_db`.`produit` (`id_produit`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `oc_pizza_db`.`commande_enregistree`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `oc_pizza_db`.`commande_enregistree` (
  `id_commande_enregistree` INT NOT NULL AUTO_INCREMENT,
  `travailleur_pizzeria_id` INT NOT NULL,
  `numero_commande` INT NOT NULL,
  PRIMARY KEY (`id_commande_enregistree`),
  INDEX `fk_commande_enregistree_commande1_idx` (`numero_commande` ASC),
  INDEX `fk_commande_enregistree_travailleur_pizzeria1_idx` (`travailleur_pizzeria_id` ASC),
  CONSTRAINT `fk_commande_enregistree_commande1`
    FOREIGN KEY (`numero_commande`)
    REFERENCES `oc_pizza_db`.`commande` (`numero_commande`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_commande_enregistree_travailleur_pizzeria1`
    FOREIGN KEY (`travailleur_pizzeria_id`)
    REFERENCES `oc_pizza_db`.`travailleur_pizzeria` (`id_travailleurs`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `oc_pizza_db`.`adresse_client`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `oc_pizza_db`.`adresse_client` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `client_id` INT NOT NULL,
  `adresse_id` INT NOT NULL,
  PRIMARY KEY (`id`),
  INDEX `fk_adresses_clients_client1_idx` (`client_id` ASC),
  INDEX `fk_adresses_clients_adresse_client1_idx` (`adresse_id` ASC),
  CONSTRAINT `fk_adresses_clients_client1`
    FOREIGN KEY (`client_id`)
    REFERENCES `oc_pizza_db`.`client` (`id_client`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_adresses_clients_adresse_client1`
    FOREIGN KEY (`adresse_id`)
    REFERENCES `oc_pizza_db`.`adresse` (`id_adresse`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


SET SQL_MODE=@OLD_SQL_MODE;
SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;
SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS;
